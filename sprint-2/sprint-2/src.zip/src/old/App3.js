import React from "react";
import "./App.css";
import axios from "axios";
import { Switch, Route, Link } from "react-router-dom";

class App3 extends React.Component {
  state = {
    videos: []
  };

  componentDidMount() {
    axios
      .get("https://project-2-api.herokuapp.com/videos?api_key=labKey")
      .then(response => {
        this.setState({
          videos: response.data
        });
      });
  }

  render() {
    if (this.state.videos.length === 0) {
      return <div>Loading...</div>;
    } else {
      const VideoLinks = this.state.videos.map(video => {
        return (
          <ul>
            <li>
              <Link to={this.state.match.params + "/" + video.id}>
                {video.id}
              </Link>
            </li>
          </ul>
        );
      });
      console.log(VideoLinks);

      return (
        <>
          <section>
            <h1>Videos</h1>
            <nav>{VideoLinks}</nav>
            <Switch>
              <Route path="/videos/:videoID" component={MainVideo} />
            </Switch>
          </section>
        </>
      );
    }
  }
}

// componentDidMount() {
//     const { match: { params } } = this.props;

//     axios.get(`/api/users/${params.userId}`)
//         .then(({ data: user }) => {
//             console.log('user', user);

//             this.setState({ user });
//         });
// }

class MainVideo extends React.Component {
  state = {
    videos: []
  };

  componentDidMount() {
    axios
      .get("https://project-2-api.herokuapp.com/videos?api_key=labKey")
      .then(response => {
        this.setState({
          videos: response.data
        });
      });
  }

  render() {
    return (
      <>
        <section>
          <h1>Family</h1>
        </section>
      </>
    );
  }
}

export default App3;
