import React, { Component } from "react";
import { Link, Switch, Route } from "react-router-dom";
//import FamilyMember from './FamilyMember'

const FamilyMember = props => {
  console.log(props);
  console.log(props.match.params);
  return <div>Family Member is: {props.match.params.memberName}</div>;
};

class Family extends Component {
  state = {
    familyMembers: [
      {
        name: "Jonathan",
        imageUrl: "images/jonathan.jpg"
      },
      {
        name: "Heather",
        imageUrl: "images/heather.jpg"
      }
    ]
  };
  render() {
    // const familyRoutes = this.state.familyMembers.map(member => {
    // This doesn't work, FamilyMember doesn't load properly
    // with the route. See if there is another way.
    //   const familyMember = <FamilyMember
    //                         name={member.name}
    //                         imageUrl={member.imageUrl}
    //                       />
    //   return (
    //     <Route path={this.props.match.path + '/' + member.name} component={TestComponent}/>
    //   )
    // })

    const familyLinks = this.state.familyMembers.map(member => {
      return (
        <Link to={this.props.match.url + "/" + member.name}>{member.name}</Link>
      );
    });

    return (
      <section>
        <h1>Family</h1>
        <Link to="/">Why Us</Link>
        <h3>Family Members</h3>
        <nav>{familyLinks}</nav>
        <Switch>
          <Route path="/family/:memberName" component={FamilyMember} />
        </Switch>
      </section>
    );
  }
}

export default Family;
