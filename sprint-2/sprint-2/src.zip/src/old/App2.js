import React from "react";
import "./App.css";
import axios from "axios";
import { Switch, Route, Link } from "react-router-dom";

//https://project-2-api.herokuapp.com/videos/1af0jruup5gu?api_key=labKey

class App extends React.Component {
  state = {
    users: []
  };

  componentDidMount() {
    // console.log('componentDidMount')
    axios
      .get("https://project-2-api.herokuapp.com/videos?api_key=labKey")
      .then(response => {
        // console.log('Axios:', response.data)
        this.setState({
          users: response.data
        });
      });
  }

  render() {
    // console.log('Render:', this.state.users)
    return (
      <div className="App">
        <nav>
          <Link to="/">Home</Link> |<Link to="/about">About</Link>
        </nav>
        <Switch>
          <Route
            path="/"
            exact
            render={props => {
              // console.log(props);
              return <HomePage users={this.state.users} />;
            }}
          />
          <Route path="/about" exact component={AboutPage} />
          <Route
            path="/user/:videoid"
            exact
            render={props => {
              // Ensure that we have users before proceeding
              if (this.state.users.length === 0) {
                return <div>Loading...</div>;
              } else {
                // 1. Get username on URL from match.params
                const videoid = props.match.params.videoid;

                // 2. Look up the user in the user array in state
                const video = this.state.users.find(video => {
                  return video.id === videoid;
                });

                // 3. Return the UserProfile Component with the user
                // information
                return <UserProfilePage video={video} />;
              }
            }}
          />
        </Switch>
      </div>
    );
  }
}

const HomePage = props => {
  // console.log(props);

  const userList = props.users.map(video => {
    return (
      <li>
        <Link to={`/user/${video.id}`}>{video.id}</Link>
      </li>
    );
  });

  return (
    <div>
      <h1>Home</h1>
      <ul>{userList}</ul>
    </div>
  );
};

const AboutPage = () => <h1>About</h1>;

const UserProfilePage = props => {
  return (
    <div>
      <h1>Video</h1>
      <h2>Video ID: {props.video.id}</h2>
      <h3>Video channel: {props.video.channel}</h3>
      <h3>Video Title: {props.video.title}</h3>
      <h3>Video image: {props.video.image}</h3>
    </div>
  );
};

export default App2;
