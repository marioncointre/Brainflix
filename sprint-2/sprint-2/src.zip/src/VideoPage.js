import React from "react";
import axios from "axios";
import Header from "./Header";
import Hero from "./Hero";
import Comments2 from "./Comments2";
import VideoList from "./VideoList";
import Description from "./Description";
import "./css/app.css";
// import VideoList from "../VideoList";
// import viewsIcon from "../assets/Icons/SVG/Icon-views.svg";
// import likesIcon from "../assets/Icons/SVG/Icon-likes.svg";

class VideoPage extends React.Component {
  state = {
    videoid: this.props.videoid,
    videos: this.props.videos,
    singleVid: [this.props.singleVid]
  };

  componentDidMount() {
    const videoidUrl = `https://project-2-api.herokuapp.com/videos/${
      this.state.videoid
    }?api_key=labKey`;

    axios.get(videoidUrl).then(response => {
      this.setState({
        singleVid: response.data
      });
    });
  }

  render() {
    const { commentsTables } = this.state.singleVid;
    console.log(commentsTables);
    // if (Object.keys(commentsTables).length === 0) return <div>Loading...</div>;
    return (
      <>
        <Header />
        <Hero videos={this.state.videos} />
        <div className="section">
          <div className="main">
            <Description videos={this.state.videos} />
            <Comments2 videos={this.state.videos} />
          </div>
          <VideoList videos={this.state.videos} />
        </div>
      </>
    );
  }
}
export default VideoPage;
