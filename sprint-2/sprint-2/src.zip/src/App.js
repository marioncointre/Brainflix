import React from "react";
import axios from "axios";
import { Switch, Route } from "react-router-dom";
import "./css/app.css";
import Header from "./Header";
import Hero from "./Hero";
import Comments2 from "./Comments2";
import VideoList from "./VideoList";
import Description from "./Description";
import VideoUploader from "./VideoUploader";
import VideoPage from "./VideoPage";

class App extends React.Component {
  state = {
    videos: [],
    singleVid: {
      title: " ",
      channel: " ",
      description: " ",
      image: " ",
      timestamp: " ",
      views: " ",
      likes: " ",
      commentsTables: []
    }
  };

  componentDidMount() {
    axios
      .get(`https://project-2-api.herokuapp.com/videos?api_key=labKey`)
      .then(response => {
        const videosArray = response.data.map(videoArray => {
          return {
            id: videoArray.id,
            title: videoArray.title,
            channel: videoArray.channel,
            image: videoArray.image
          };
        });

        this.setState({
          videos: videosArray
        });

        const videoidUrl = `https://project-2-api.herokuapp.com/videos/${
          response.data[0].id
        }?api_key=labKey`;

        axios.get(videoidUrl).then(response => {
          this.setState({
            singleVid: {
              title: response.data.title,
              channel: response.data.channel,
              description: response.data.description,
              image: response.data.image,
              timestamp: response.data.timestamp,
              views: response.data.views,
              likes: response.data.likes,
              commentsTables: response.data.comments
            }
          });
        });
      });
  }

  // componentDidUpdate {
  //   // this.props.match.id and assign it to a variable
  //   // get axios url and add the id to it to get the data for said video
  //   //set second state so it displays data

  // }

  render() {
    return (
      <>
        {/* <Switch>
          <Route path="/" Component={App} />
          <Route
            path="/video/:videoid"
            exact
            render={props => {
              return (
                <VideoPage
                  videoid={props.match.params.videoid}
                  videos={this.state.videos}
                  commentsTables={this.state.singleVid}
                />
              );
            }}
          />
          <Route path="/upload-video" Component={VideoUploader} />
        </Switch>
 */}
        <div className="App">
          <Header />
          <Hero singleVid={this.state.singleVid} />
          <div className="section">
            <div className="main">
              <Description singleVid={this.state.singleVid} />
              <Comments2 commentsTable={this.state.singleVid} />
            </div>
            <VideoList videos={this.state.videos} />
            {/* <VideoPage videos={this.state.singleVid} /> */}
          </div>
        </div>
      </>
    );
  }
}

export default App;
