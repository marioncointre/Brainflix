import React from "react";
import { BrowserRouter, Switch, Route, Link } from "react-router-dom";

class Comments2 extends React.Component {
  render() {
    const commentsTable = this.props;
    console.log(commentsTable);
    // const commentsNb = this.props.commentsTable.length;
    if (Object.keys(commentsTable).length === 0) return <div>loading...</div>;

    return (
      <>
        <div className="comments">
          <div className="comments__title">{commentsTable.length}Comments</div>
          <h4>JOIN THE CONVERSATION </h4>
          <div className="form">
            <img src="assets/images/Mohan-muruge.jpg" />
            <form id="myForm" action="submit" method="post">
              <div className="formComment">
                <textarea
                  name="Comment"
                  id="Comment"
                  placeholder=" That was easily the most spectacular BMX moment ever."
                />
              </div>
              <button id="Btn" type="submit">
                COMMENT
              </button>
            </form>
          </div>
          {/* <CommentList commentsTable={this.props} /> */}
        </div>
      </>
    );
  }
}
// const CommentList = props => {
//   const { commentsTable } = props;
//   console.log(commentsTable);
//   const comments = commentsTable.map(com => {
//     if (Object.keys(CommentList).length !== 0);
//     return (
//       <>
//         <div class="comments__table">
//           <div className="published">
//             <div className="published__img">
//               <div className="published__icon">{""}</div>
//             </div>
//             <div className="published__body">
//               <p className="username">{com.name}</p>
//               <p className="date">{com.timestamp}</p>
//               <div className="input">{com.comment}</div>
//             </div>
//           </div>
//         </div>
//       </>
//     );
//   });
//   return <div>{comments}</div>;
// };

export default Comments2;
